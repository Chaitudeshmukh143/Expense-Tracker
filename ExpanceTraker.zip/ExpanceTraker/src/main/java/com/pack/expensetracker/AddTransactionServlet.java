package com.pack.expensetracker;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.time.LocalDate;

@WebServlet("/ats")
public class AddTransactionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
    	TransactionBean tb =new TransactionBean();

        tb.setType(request.getParameter("type"));
        tb.setCategory(request.getParameter("category"));
        tb.setAmount(request.getParameter("amount"));
        tb.setDescription(request.getParameter("description"));
        String dateStr = request.getParameter("date");
        java.sql.Date sqlDate = java.sql.Date.valueOf(dateStr);
        tb.setDate(sqlDate);
        

        
        TransactionDAO txd =new TransactionDAO();
        int rowCount=txd.insertData(tb);
        if(rowCount>0)
		{
        	response.sendRedirect("success.jsp");
		}
       
    }
}

