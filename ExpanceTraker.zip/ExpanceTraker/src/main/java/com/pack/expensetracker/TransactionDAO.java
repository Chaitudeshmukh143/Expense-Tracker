package com.pack.expensetracker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;



public class TransactionDAO 
{
	Connection con = DBConnect.getCon();
      public int insertData(TransactionBean txb)
      { 
    	  int rowcount=0;
    	  try
  		{
  			
  			PreparedStatement pst=con.prepareStatement("INSERT INTO transactions (type, category, amount, date_of_entry) VALUES (?, ?, ?, ?)");
  			
  			pst.setString(1, txb.getType());
  			pst.setString(2, txb.getCategory());
  			pst.setDouble(3, txb.getAmount());
            pst.setDate(4, txb.getDate());
  			
  			
  		rowcount=pst.executeUpdate();
  			
  			
  		}
  		catch(Exception e)
  		{
  			e.printStackTrace();
  		}
    	  
    	  
    	  return rowcount;
    	  
      }
      
      
      public List<TransactionBean> getAllTransactions() {
    	    List<TransactionBean> list = new ArrayList<>();
    	    try {
    	    	
    	        PreparedStatement ps = con.prepareStatement("SELECT * FROM transactions");
    	        ResultSet rs = ps.executeQuery();

    	        while (rs.next()) {
    	            TransactionBean bean = new TransactionBean();
    	            bean.setId(rs.getInt("id"));
    	            bean.setType(rs.getString("type"));
    	            bean.setCategory(rs.getString("category"));
    	            bean.setAmount(Double.toString(rs.getDouble("amount")));
    	            bean.setDate(rs.getDate("date_of_entry"));  
    	            list.add(bean);
    	        }

    	        
    	    }
    	    catch (Exception e) 
    	    {
    	        e.printStackTrace();
    	    }
    	    return list;
    	}
      public Map<String, Map<String, Double>> getMonthlyCategorySummary() throws SQLException 
      {
    	    Map<String, Map<String, Double>> summary = new LinkedHashMap<>();

    	    String sql = "SELECT TO_CHAR(DATE_OF_ENTRY, 'YYYY-MM') AS month, category, SUM(amount) AS total FROM transactions GROUP BY TO_CHAR(DATE_OF_ENTRY, 'YYYY-MM'), category ORDER BY TO_CHAR(DATE_OF_ENTRY, 'YYYY-MM') DESC";


    	    try 
    	    {
    	    		
    	         PreparedStatement stmt = con.prepareStatement(sql);
    	         ResultSet rs = stmt.executeQuery();
    	        		 
    	   

    	           while(rs.next()) 
    	           {
    	            String month = rs.getString("month");
    	            String category = rs.getString("category");
    	            double total = rs.getDouble("total");

    	            summary.putIfAbsent(month, new LinkedHashMap<>());
    	            summary.get(month).put(category, total);
    	           }
    	    }
    	    catch (Exception e) 
    	    {
    	        e.printStackTrace();
    	    }

    	    return summary;
    	}
      
      public List<TransactionBean> getIncomeTransactions() {
          List<TransactionBean> list = new ArrayList<>();
          try (
               PreparedStatement pst = con.prepareStatement("SELECT * FROM transactions WHERE UPPER(type) = 'INCOME'")) {
              ResultSet rs = pst.executeQuery();
              while (rs.next()) {
                  TransactionBean tx = new TransactionBean();
                  tx.setType(rs.getString("type"));
                  tx.setCategory(rs.getString("category"));
                  tx.setAmount(Double.toString(rs.getDouble("amount")));
                  tx.setDate(rs.getDate("date_of_entry"));
                  list.add(tx);
              }
          } catch (Exception e) {
              e.printStackTrace();
          }
          return list;
      }

      public List<TransactionBean> getExpenseTransactions() {
          List<TransactionBean> list = new ArrayList<>();
          try (
               PreparedStatement pst = con.prepareStatement("SELECT * FROM transactions WHERE UPPER(type) = 'EXPENSE'")) {
              ResultSet rs = pst.executeQuery();
              while (rs.next()) {
                  TransactionBean tx = new TransactionBean();
                  tx.setType(rs.getString("type"));
                  tx.setCategory(rs.getString("category"));
                  tx.setAmount(Double.toString(rs.getDouble("amount")));
                  tx.setDate(rs.getDate("date_of_entry"));
                  list.add(tx);
              }
          } catch (Exception e) {
              e.printStackTrace();
          }
          return list;
      }

      public double getTotalIncome() {
          double total = 0;
          try (
               PreparedStatement pst = con.prepareStatement("SELECT SUM(amount) FROM transactions WHERE UPPER(type) = 'INCOME'")) {
              ResultSet rs = pst.executeQuery();
              if (rs.next()) {
                  total = rs.getDouble(1);
              }
          } catch (Exception e) {
              e.printStackTrace();
          }
          return total;
      }

      public double getTotalExpense() {
          double total = 0;
          try (
               PreparedStatement pst = con.prepareStatement("SELECT SUM(amount) FROM transactions WHERE UPPER(type) = 'EXPENSE'")) {
              ResultSet rs = pst.executeQuery();
              if (rs.next()) {
                  total = rs.getDouble(1);
              }
          } catch (Exception e) {
              e.printStackTrace();
          }
          return total;
      }


    
}
