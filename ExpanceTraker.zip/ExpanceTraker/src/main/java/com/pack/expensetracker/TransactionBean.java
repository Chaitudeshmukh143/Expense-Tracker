package com.pack.expensetracker;

import java.sql.Date;
import java.time.LocalDate;

public class TransactionBean
{
	private int Id;
   
	private String type;
    private String category;
    private double amount;
    private String description;
    private Date date;
   

    

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(String string) {
		this.amount = Double.parseDouble(string);
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date string) {
		this.date = string;
	}
	 public int getId() {
			return Id;
		}
		public void setId(int id) {
			Id = id;
		}
		

}

